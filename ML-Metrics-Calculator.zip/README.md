# 📊 ML Model Metrics Calculator

A simple Python script to calculate performance metrics (MAE, RMSE, R², MAPE) for multiple models using actual and predicted values.

## 💻 How It Works

1. Place your CSV in the `data/` folder. It must have:
   - A column called `actual` for true values.
   - One or more columns for model predictions (`model1`, `model2`, etc.)

2. Update the config in `model_metrics.py`:
```python
DATA_PATH = 'data/example_data.csv'
ACTUAL_COL = 'actual'
PREDICTED_MODELS = ['model1', 'model2']
```

3. Run the script:
```bash
python model_metrics.py
```

## 📈 Output

For each model, it will print:

- MAE (Mean Absolute Error)
- RMSE (Root Mean Square Error)
- R² Score (Coefficient of Determination)
- MAPE (Mean Absolute Percentage Error)

## 🧪 Sample Data Structure

| actual | model1 | model2 |
|--------|--------|--------|
| 10     | 9.5    | 10.2   |
| 12     | 11.8   | 12.1   |
| 15     | 14.5   | 15.2   |

## 📄 License

This project is licensed under the MIT License.