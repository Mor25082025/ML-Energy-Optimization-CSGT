import pandas as pd
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# ---------------- Configuration ---------------- #
DATA_PATH = 'data/example_data.csv'
ACTUAL_COL = 'actual'
PREDICTED_MODELS = ['model1', 'model2']
# ------------------------------------------------ #

def mean_absolute_percentage_error(y_true, y_pred):
    y_true, y_pred = pd.Series(y_true), pd.Series(y_pred)
    return (abs((y_true - y_pred) / y_true).replace([float('inf'), -float('inf')], 0)).mean() * 100

def calculate_metrics(actual, predicted):
    return {
        'MAE': mean_absolute_error(actual, predicted),
        'RMSE': mean_squared_error(actual, predicted, squared=False),
        'R2': r2_score(actual, predicted),
        'MAPE': mean_absolute_percentage_error(actual, predicted)
    }

def main():
    data = pd.read_csv(DATA_PATH)
    actual = data[ACTUAL_COL]
    metrics = {}

    for model in PREDICTED_MODELS:
        predicted = data[model]
        metrics[model] = calculate_metrics(actual, predicted)

    print("📊 Model Performance Metrics")
    for model, values in metrics.items():
        print(f"\nModel: {model}")
        for metric_name, value in values.items():
            print(f"{metric_name}: {value:.4f}")

if __name__ == '__main__':
    main()